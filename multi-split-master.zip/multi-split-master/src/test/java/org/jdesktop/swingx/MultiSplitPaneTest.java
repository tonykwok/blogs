/*
 * MultiSplitPaneTest.java
 * JUnit based test
 *
 * Created on February 2, 2006, 12:14 PM
 */

package org.jdesktop.swingx;

import junit.framework.*;

/**
 *
 * @author Hans Muller
 */
public class MultiSplitPaneTest extends TestCase {

    public MultiSplitPaneTest(String testName) {
        super(testName);
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(MultiSplitPaneTest.class);
        return suite;
    }

    public void testArticleExample1() {
    }
}
